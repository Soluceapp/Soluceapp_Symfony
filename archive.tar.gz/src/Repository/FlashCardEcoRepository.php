<?php

namespace App\Repository;

use App\Entity\FlashCardEco;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<FlashCardEco>
 *
 * @method FlashCardEco|null find($id, $lockMode = null, $lockVersion = null)
 * @method FlashCardEco|null findOneBy(array $criteria, array $orderBy = null)
 * @method FlashCardEco[]    findAll()
 * @method FlashCardEco[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class FlashCardEcoRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, FlashCardEco::class);
    }

 // Fonction nécessaire au repository pour répartir par classe (une donnée en mémoire)
 // Fonction utilisée lors du template d'affichage des questions de l'entrainement de flashcard
 public function findRandomCardByClassId(int $idClasse): ?FlashCardEco
 {
     // Étape 1 : Récupérer le nombre total de flashcards pour la classe choisie
     $queryBuilder = $this->createQueryBuilder('f')
         ->select('COUNT(f.id)')
         ->where('f.classe = :idClasse')
         ->setParameter('idClasse', $idClasse);
 
     $count = $queryBuilder->getQuery()->getSingleScalarResult();
 
     if ($count == 0) {
         return null; // Aucun enregistrement correspondant
     }
 
     // Étape 2 : Calculer un décalage (offset) aléatoire
     $randomOffset = random_int(0, $count - 1);
 
     // Étape 3 : Récupérer une flashcard avec cet offset
     return $this->createQueryBuilder('f')
         ->where('f.classe = :idClasse')
         ->setParameter('idClasse', $idClasse)
         ->setFirstResult($randomOffset)
         ->setMaxResults(1)
         ->getQuery()
         ->getOneOrNullResult();
 }
 
 // Utile pour la présentation des questions
 public function findAllByClassId(int $idClasse): array
 {
     $results = $this->createQueryBuilder('f')
         ->where('f.classe = :idClasse')
         ->setParameter('idClasse', $idClasse)
         ->getQuery()
         ->getResult();
 
     shuffle($results); // Mélange les résultats côté PHP
     return $results;
 }

}