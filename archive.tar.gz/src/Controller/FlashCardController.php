<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use App\Form\ClasseSelectionType;
use App\Repository\FlashCardEcoRepository;
use App\Repository\FlashCardGestionRepository;
use App\Repository\FlashCardOutilGestionRepository;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use App\Security\Nettoyeur;

class FlashCardController extends AbstractController
{
    // Accueil : Acceuil la réponse du header et demande niveau de classe de l'élève
    #[Route('/flash/card', name: 'app_flash_card')]
    public function index(
        Request $request,
        SessionInterface $session, 
        FlashCardEcoRepository $flashCardEcoRepository,
    ): Response {
        // Récupérer le contexte depuis l'URL et le néttoie ("eco" ou "gestion").
        $this->denyAccessUnlessGranted('IS_AUTHENTICATED');
        $context = Nettoyeur::nettoyeur_str($request->query->get('context', 'default'));
        
        // Création du formulaire du choix de niveau
        $form = $this->createForm(ClasseSelectionType::class);
        $form->handleRequest($request);

        // Vérifier si le formulaire est soumis et valide
        if ($form->isSubmitted() && $form->isValid()) {
            $classeChoisie = $form->get('classe')->getData();
    
            // Rediriger en fonction du contexte
            if ($context === "eco") {

                // Envoie du type de flashcard et de son type de classe
                return $this->redirectToRoute('app_flashcardeco', [
                        'id' => $classeChoisie->getId(),
                        'choixcard' => $context,
                    ]);
            }
            if ($context === "gestion") {

                // Envoie du type de flashcard et de son type de classe
                return $this->redirectToRoute('app_flashcardgestion', [
                    'id' => $classeChoisie->getId(),
                    'choixcard' => $context,
                ]);
            }
            if ($context === "outilgestion") {

                // Envoie du type de flashcard et de son type de classe
                return $this->redirectToRoute('app_flashcardoutilgestion', [
                    'id' => $classeChoisie->getId(),
                    'choixcard' => $context,
                ]);
            }
        }
    
        // Vide la session de randomCards (en cas de callback)
        $session->set('randomCards', '');
        $session->set('test', '');

        // Nécessaire pour utiliser le même template (évite erreur)
        $resultatflash = Null;

        // Nécessaire pour vider la variable countflashcorrect pour la suite
        if (empty($countflashcorrect)) {$countflashcorrect = 0;}
        $session->set('countflashcorrect', $countflashcorrect);

        // Rendre le template avec les données nécessaires
        return $this->render('activities/flashcard.html.twig', [
            'ClasseSelectionType' => $form->createView(),
            'choixcard' => htmlspecialchars($context),
            'randomCard' => Null,
            'resultatflash' => $resultatflash,
        ]);
    }
    
    // Crée activité flashcard eco
    #[Route('/flash/card/eco', name: 'app_flashcardeco')]
    public function flashcardeco(
        Request $request,
        FlashCardEcoRepository $flashCardEcoRepository,
        SessionInterface $session): Response
    {
        // Récupérer l'id de la classe choisie si elle exite (spécial 1 template)
        $this->denyAccessUnlessGranted('IS_AUTHENTICATED');
        $id = intval($request->query->get('id', ''));
        if(!empty($id)) {$session->set('idclasse', $id);}
        $idClasse = Nettoyeur::nettoyeur_int(intval($session->get('idclasse')));

        // Récupérer une flashcard aléatoire pour cette classe (vérifie si en session)
        if (!$idClasse) {  return $this->redirectToRoute('app_flash_card'); }
        $randomCards = Nettoyeur::cleanCardEco($session->get('randomCards', ""));
        if (!$randomCards) { $randomCards = $flashCardEcoRepository->findAllByClassId($idClasse);}

        // Vérifier si $randomCards est bien une collection et récupérer le premier élément.
        $randomCard = reset($randomCards); 
        if(!$randomCard) {return $this->redirectToRoute('home');} 
        $session->set('randomCards', array_slice($randomCards, 1));  

        // Récupère le résultat par les boutons correct et à revoir. Nettoyeur::nettoyeur_str évite injection (utilise un int).
        $resultatflash = intval(Nettoyeur::nettoyeur_str($request->query->get('resultatflash', '')));

        // In(dé)crémente la variable countflashcorrect en fonction de resultatflash (note mini 8/20)
        if (empty($countflashcorrect)) {$countflashcorrect = 0;}
        $countflashcorrect = intval(Nettoyeur::nettoyeur_str($session->get('countflashcorrect',0)));       
        switch($resultatflash){
            // Utile pour le premier affichage
            case Null :
                $resultatflash="";
                $countflashcorrect="";
                break;
            case "1": // "correct"
                if($countflashcorrect<8){$countflashcorrect=8;}
                $countflashcorrect++;
                if($countflashcorrect>20){$countflashcorrect=20;}
                // Mise en session de countflashcorrect
                $session->set('countflashcorrect', $countflashcorrect);
                break;
            case "2": // "à revoir"
                // $countflashcorrect--; (pour l'entrainement je n'enlève pas de point)
                if($countflashcorrect<8){$countflashcorrect=8;}
                // Mise en session de countflashcorrect
                $session->set('countflashcorrect', $countflashcorrect);
                break;
            default:
                echo "";}

        return $this->render('activities/flashcard.html.twig', [
            'randomCard' => $randomCard,
            'choixcard' => 'eco',
            'ClasseSelectionType' => Null,
            'resultatflash' => htmlspecialchars($countflashcorrect),
        ]);
    }
    
    // Crée activité flashcard gestion
    #[Route('/flash/card/gestion', name: 'app_flashcardgestion')]
    public function flashcardgestion(
        Request $request,
        FlashCardGestionRepository $flashCardGestionRepository,
        SessionInterface $session): Response
    {
        // Récupérer l'id de la classe choisie si elle exite (spécial 1 template)
        $this->denyAccessUnlessGranted('IS_AUTHENTICATED');
        $id = intval($request->query->get('id', ''));
        if(!empty($id)) {$session->set('idclasse', $id);}
        $idClasse = Nettoyeur::nettoyeur_int(intval($session->get('idclasse')));

        // Récupérer une flashcard aléatoire pour cette classe (vérifie si en session)
        if (!$idClasse) {  return $this->redirectToRoute('app_flash_card'); }
        $randomCards = Nettoyeur::cleanCardGestion($session->get('randomCards', ""));
        if (!$randomCards) { $randomCards = $flashCardGestionRepository->findAllByClassId($idClasse);}

        // Vérifier si $randomCards est bien une collection et récupérer le premier élément.
        $randomCard = reset($randomCards);
        if(!$randomCard) {return $this->redirectToRoute('home');}  
        $session->set('randomCards', array_slice($randomCards, 1)); 

        // Récupère le résultat par les boutons correct et à revoir.Nettoyeur::nettoyeur_str( évite injection.
        $resultatflash = intval(Nettoyeur::nettoyeur_str($request->query->get('resultatflash', '')));

        // In(dé)crémente la variable countflashcorrect en fonction de resultatflash (note mini 8/20)
        if (empty($countflashcorrect)) {$countflashcorrect = 0;}
        $countflashcorrect = intval(Nettoyeur::nettoyeur_str($session->get('countflashcorrect',0)));       
        switch($resultatflash){
            // Utile pour le premier affichage
            case Null :
                $resultatflash="";
                $countflashcorrect="";
                break;
            case "1":
                if($countflashcorrect<8){$countflashcorrect=8;}
                $countflashcorrect++;
                if($countflashcorrect>20){$countflashcorrect=20;}
                // Mise en session de countflashcorrect
                $session->set('countflashcorrect', $countflashcorrect);
                break;
            case "2":
                // $countflashcorrect--; (pour l'entrainement je n'enlève pas de point)
                if($countflashcorrect<8){$countflashcorrect=8;}
                // Mise en session de countflashcorrect
                $session->set('countflashcorrect', $countflashcorrect);
                break;
            default:
                echo "";}

        return $this->render('activities/flashcard.html.twig', [
            'randomCard' => $randomCard,
            'choixcard' => 'gestion',
            'ClasseSelectionType' => Null,
            'resultatflash' => htmlspecialchars($countflashcorrect),
        ]);
    }

// Crée activité flashcard outil de gestion
#[Route('/flash/card/outil_gestion', name: 'app_flashcardoutilgestion')]
public function flashcardoutilgestion(
    Request $request,
    FlashCardOutilGestionRepository $flashCardOutilGestionRepository,
    SessionInterface $session): Response
{
    // Récupérer l'id de la classe choisie si elle exite (spécial 1 template)
    $this->denyAccessUnlessGranted('IS_AUTHENTICATED');
    $id = intval($request->query->get('id', ''));
    if(!empty($id)) {$session->set('idclasse', $id);}
    $idClasse = Nettoyeur::nettoyeur_int(intval($session->get('idclasse')));

    // Récupérer une flashcard aléatoire pour cette classe (vérifie si en session)
    if (!$idClasse) {  return $this->redirectToRoute('app_flash_card'); }
    $randomCards = Nettoyeur::cleanCardOutilGestion($session->get('randomCards', ""));
    if (!$randomCards) { $randomCards = $flashCardOutilGestionRepository->findAllByClassId($idClasse);}

    // Vérifier si $randomCards est bien une collection et récupérer le premier élément.
    $randomCard = reset($randomCards);
    if(!$randomCard) {return $this->redirectToRoute('home');}  
    $session->set('randomCards', array_slice($randomCards, 1)); 

    // Récupère le résultat par les boutons correct et à revoir.Nettoyeur::nettoyeur_str( évite injection.
    $resultatflash = intval(Nettoyeur::nettoyeur_str($request->query->get('resultatflash', '')));

    // In(dé)crémente la variable countflashcorrect en fonction de resultatflash (note mini 8/20)
    if (empty($countflashcorrect)) {$countflashcorrect = 0;}
    $countflashcorrect = intval(Nettoyeur::nettoyeur_str($session->get('countflashcorrect',0)));       
    switch($resultatflash){
        // Utile pour le premier affichage
        case Null :
            $resultatflash="";
            $countflashcorrect="";
            break;
        case "1":
            if($countflashcorrect<8){$countflashcorrect=8;}
            $countflashcorrect++;
            if($countflashcorrect>20){$countflashcorrect=20;}
            // Mise en session de countflashcorrect
            $session->set('countflashcorrect', $countflashcorrect);
            break;
        case "2":
            // $countflashcorrect--; (pour l'entrainement je n'enlève pas de point)
            if($countflashcorrect<8){$countflashcorrect=8;}
            // Mise en session de countflashcorrect
            $session->set('countflashcorrect', $countflashcorrect);
            break;
        default:
            echo "";}

    return $this->render('activities/flashcard.html.twig', [
        'randomCard' => $randomCard,
        'choixcard' => 'outilgestion',
        'ClasseSelectionType' => Null,
        'resultatflash' => htmlspecialchars($countflashcorrect),
    ]);
}



}
