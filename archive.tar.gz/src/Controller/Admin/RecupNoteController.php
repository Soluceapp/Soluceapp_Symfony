<?php

namespace App\Controller\Admin;

use App\Security\Nettoyeur;
use App\Entity\Dutil;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use App\Form\RecupnoteFormType;
use App\Form\ChangepointsFormType;
use App\Form\ChangeevalsFormType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\SessionInterface;

class RecupNoteController extends AbstractController
{
    #[Route('/admin/notes', name: 'app_recupnote')]
    public function recupnote(Request $request,EntityManagerInterface $entityManager, Dutil $dutil,SessionInterface $session): Response
    {$this->denyAccessUnlessGranted('IS_AUTHENTICATED');

        //Récupère le formulaire pour choisir la classe et le domaine
        $user = new Dutil();
        $form = $this->createForm(RecupnoteFormType::class, $user);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) 
        {
            // Récupération et conversion utile du formulaire $form
            $Iddomaineverif=($form->get('id_domain')->getData())->getId();
            $Iddomaineverif=Nettoyeur::nettoyeur_int($Iddomaineverif);

            $Idclasseverif=($form->get('classe')->getData())->getId();
            $Idclasseverif=Nettoyeur::nettoyeur_int($Idclasseverif);

            $dutil=$entityManager->getRepository(Dutil::class)->findAll();

            //Utile pour classifier en changepointsform
            $session = $request->getSession(); 
            $session->set('id_domain', $Iddomaineverif);
            $session->set('id_classe', $Idclasseverif);
            
           
        }else{$Idclasseverif=1;$Iddomaineverif=$Idclasseverif=$points=0;}

        // création du $form_points par utilisation de données en session. 
        $Idclasseverif = Nettoyeur::nettoyeur_int($session->get('id_classe'));
        $Iddomaineverif = Nettoyeur::nettoyeur_int($session->get('id_domain'));
        $form_points = $this->createForm(ChangepointsFormType::class, $user,array('id_classe'=>$Idclasseverif,'id_domain'=>$Iddomaineverif));
        $form_points->handleRequest($request);

        if ($form_points->isSubmitted() && $form_points->isValid()) 
        {
            $dutil=$form_points->get('Nom')->getData(); 
            $variapoint=$form_points->get('points')->getData();;          
            $points=$dutil->getPoints();
            $points=$points+$variapoint;
            $dutil->setPoints($points);           

            // Pas possible d'utiliser donnenoteservice : ? firewall.
            $note=$dutil->getNote();
            $points=$dutil->getPoints();
            if($points<=4){$note=$points;}else{$note=4+(($points-4)*0.25);} 
            $dutil->setNote($note);

            $entityManager->persist($dutil);
            $entityManager->flush();
            
        }
           
        return $this->render('admin/recupnote.html.twig', [
            'RecupnoteFormType' => $form->createView(),
            'ChangepointsFormType' => $form_points->createView(),
            'dutil'=>$dutil,
            'Iddomaineverif'=>htmlspecialchars($Iddomaineverif),
            'Idclasseverif'=>htmlspecialchars($Idclasseverif),
        ]);
        
        
    
    }
    #[Route('/admin/evals', name: 'app_recupeval')]
    public function recupeval(Request $request,EntityManagerInterface $entityManager, Dutil $dutil,SessionInterface $session): Response
    {$this->denyAccessUnlessGranted('IS_AUTHENTICATED');

        //Récupère le formulaire pour choisir la classe et le domaine
        $user = new Dutil();
        $form = $this->createForm(RecupnoteFormType::class, $user);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) 
        {
            // Récupération et conversion utile du formulaire $form
            $Iddomaineverif=($form->get('id_domain')->getData())->getId();
            $Iddomaineverif=Nettoyeur::nettoyeur_int($Iddomaineverif);

            $Idclasseverif=($form->get('classe')->getData())->getId();
            $Idclasseverif=Nettoyeur::nettoyeur_int($Idclasseverif);

            $dutil=$entityManager->getRepository(Dutil::class)->findAll();

            //Utile pour classifier en changepointsform
            $session = $request->getSession(); 
            $session->set('id_domain', $Iddomaineverif);
            $session->set('id_classe', $Idclasseverif);
            
           
        }else{$Idclasseverif=1;$Iddomaineverif=$Idclasseverif=$points=0;}

        // création du $form_evals par utilisation de données en session. 
        
        $Idclasseverif = Nettoyeur::nettoyeur_int($session->get('id_classe'));
        $Iddomaineverif = Nettoyeur::nettoyeur_int($session->get('id_domain'));
        $form_evals = $this->createForm(ChangeevalsFormType::class, $user,array('id_classe'=>$Idclasseverif,'id_domain'=>$Iddomaineverif));
        $form_evals->handleRequest($request);

        if ($form_evals->isSubmitted() && $form_evals->isValid()) 
        {
            $dutil=$form_evals->get('Nom')->getData(); 
            $variapoint=Nettoyeur::nettoyeur_int($form_evals->get('points')->getData());;          
            $evals=$dutil->getNoteEvalEco();
            $evals=$evals+$variapoint;
            $dutil->setNoteEvalEco($evals);           

            $entityManager->persist($dutil);
            $entityManager->flush();
            
        }
           
        return $this->render('admin/recupeval.html.twig', [
            'RecupnoteFormType' => $form->createView(),
            'ChangeevalsFormType' => $form_evals->createView(),
            'dutil'=>$dutil,
            'Iddomaineverif'=>htmlspecialchars($Iddomaineverif), 
            'Idclasseverif'=>htmlspecialchars($Idclasseverif),
        ]);
        
        
    
    }

}
