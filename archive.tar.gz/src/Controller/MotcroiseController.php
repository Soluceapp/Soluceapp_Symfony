<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Scenario;
use App\Entity\Dutil;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use App\Security\Nettoyeur;

//
// Méthodes relatives à l'activité de mot croisé
//
class MotcroiseController extends AbstractController
{

    // Permet de choisir le scénario des mots croisés
    #[Route('/activities/motcroise', name: 'app_motcroise')]
    public function index(
        EntityManagerInterface $entityManager): Response
    {    
        // Vérifie si l'utilisateur est authentifié
        $this->denyAccessUnlessGranted('IS_AUTHENTICATED');

        // Récupère l'utilisateur connecté
        $dutil = $entityManager->getRepository(Dutil::class)->find($this->getUser());

        // Récupère la classe de l'utilisateur
        $classe = $dutil->getClasse();

        // Récupère les scénarios associés à la classe
        $scenarios = $entityManager->getRepository(Scenario::class)->findBy(['classe' => $classe]);
    
        return $this->render('activities/motcroise.html.twig', [
            'scenarios' => $scenarios, // Liste des scénarios filtrés
            'classe' => $classe, // Classe de l'utilisateur
       
        ]);
    }

    // Permet de faire le mots croisés
    #[Route('/activities/motcroise/motcroise', name: 'app_motcroise2')]
    public function motcroise2(
        Dutil $dutil,
        SessionInterface $session,
        Scenario $Scenario,
        EntityManagerInterface $entityManager,
        Request $request): Response
    {
        
    // Vérifie si l'utilisateur est authentifié et récupère l'utilisateur
    $this->denyAccessUnlessGranted('IS_AUTHENTICATED');
    $user = $this->getUser();

    // Récupérer l'ID du scénario depuis le formulaire et nettoyée
    $idScenario = Nettoyeur::nettoyeur_int(intval(($request->request->get('id_scenario'))));
    if (!$idScenario) {
        $this->addFlash('danger', 'Veuillez sélectionner un scénario.');
        return $this->redirectToRoute('app_chevaux');
    }
        
    // Charger le scénario correspondant
    $scenario = $entityManager->getRepository(Scenario::class)->find($idScenario);
    if (!$scenario) {
        $this->addFlash('danger', 'Scénario introuvable.');
        return $this->redirectToRoute('app_motcroise');
    }
        
    // Récupération //mise en session de l'id pour récupération en résultat.de la variable motCroiseFait (array de 1 à 100) enregistrée précédement pour comparaison
    $dutil = $entityManager->getRepository(Dutil::class)->find($this->getUser());
    $motCroiseFait=$dutil->getMotcroisefait();
    
    // Comparaison entre idScenario et motCroiseFait mémorisé (variable intermédiaire indexScenario)
    if(!$idScenario==""&&$idScenario>0&&$idScenario<100){$indexScenario=$motCroiseFait[$idScenario];}
        else
        {
            $this->addFlash('info','Il faut indiquer un numéro de scénario.');
            return $this->redirectToRoute('app_motcroise');  
        }
    if($indexScenario==1)
        {
            $this->addFlash('success','Mot croisé déjà réalisé.');
            return $this->redirectToRoute('app_motcroise');  
        }  
    
    // Mise en session de l'id pour récupération en résultat.
    $session->set("id_scenario",$idScenario);

    // Récupération d'information à afficher partir de l'id nettoyée et de la base.
    if(isset($scenario))
        {
        $name_scenario=$scenario->getNameScenario();
        $lienimage=$scenario->getLienimage();
        $lienmotcroise=$scenario->getLienmotcroise();

        $reponsemotcroise=$scenario->getReponsemotcroise();
        }
    else {$this->addFlash('success','Mots croisés déjà réalisé ou impossible.');return $this->redirectToRoute('app_activities');}

    return $this->render('activities/motcroise2.html.twig', [
       
            'name_scenario'=>$name_scenario,
            'lienmotcroise'=>$lienmotcroise,
            'reponsemotcroise'=>$reponsemotcroise,
        ]);
    }
}
