<?php

namespace App\Entity;

use App\Repository\DomaineStudentRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;


#[ORM\Entity(repositoryClass: DomaineStudentRepository::class)]
class DomaineStudent
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $Namedomaine = null;

    #[ORM\OneToMany(mappedBy: 'id_domain', targetEntity: Dutil::class)]
    private Collection $dutils;

    #[ORM\Column(nullable: true)]
    private ?bool $acces_eval_flashcard_seconde = null;

    #[ORM\Column(nullable: true)]
    private ?bool $acces_eval_flashcard_premiere = null;

    #[ORM\Column(nullable: true)]
    private ?bool $acces_eval_flashcard_terminale = null;

    #[ORM\Column(nullable: true)]
    private ?bool $acces_eval_flashcard_fac = null;

    #[ORM\Column(nullable: true)]
    private ?bool $acces_eval_flashcard_special = null;

    #[ORM\Column(nullable: true)]
    private ?bool $acces_flashcardoutilgestion = null;

    // ----------------------------------------------------------

    public function __construct()
    {
        $this->dutils = new ArrayCollection();
    }

   // get -------------------------------------------------------

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNamedomaine(): ?string
    {
        return $this->Namedomaine;
    }

    /**
     * @return Collection<int, Dutil>
     */
    public function getDutils(): Collection
    {
        return $this->dutils;
    }

    public function getAccesEvalFlashcardSeconde(): ?bool
    {
        return $this->acces_eval_flashcard_seconde;
    }

    // Doublon pour régler problème de nom easyadmin
    public function getacces_eval_flashcard_seconde(): ?bool
    {
        return $this->acces_eval_flashcard_seconde;
    }

    public function getAccesEvalFlashcardPremiere(): ?bool
    {
        return $this->acces_eval_flashcard_premiere;
    }

    // Doublon pour régler problème de nom easyadmin
    public function getacces_eval_flashcard_premiere(): ?bool
    {
        return $this->acces_eval_flashcard_premiere;
    }

    public function getAccesEvalFlashcardTerminale(): ?bool
    {
        return $this->acces_eval_flashcard_terminale;
    }

    // Doublon pour régler problème de nom easyadmin
    public function getacces_eval_flashcard_terminale(): ?bool
    {
        return $this->acces_eval_flashcard_terminale;
    }

    public function getAccesEvalFlashcardFac(): ?bool
    {
        return $this->acces_eval_flashcard_fac;
    }

    // Doublon pour régler problème de nom easyadmin
    public function getacces_eval_flashcard_fac(): ?bool
    {
        return $this->acces_eval_flashcard_fac;
    }

    public function getAccesEvalFlashcardSpecial(): ?bool
    {
        return $this->acces_eval_flashcard_special;
    }

    // Doublon pour régler problème de nom easyadmin
    public function getacces_eval_flashcard_special(): ?bool
    {
        return $this->acces_eval_flashcard_special;
    }


    public function getAccesFlashcardOutilGestion(): ?bool
    {
        return $this->acces_flashcardoutilgestion;
    }

    public function getacces_flashcardoutilgestion(): ?bool
    {
        return $this->acces_flashcardoutilgestion;
    }

    // set ------------------------------------------------------

    public function setNamedomaine(?string $Namedomaine): static
    {
        $this->Namedomaine = $Namedomaine;

        return $this;
    }

    
    public function addDutil(Dutil $dutil): static
    {
        if (!$this->dutils->contains($dutil)) {
            $this->dutils->add($dutil);
            $dutil->setIdDomain($this);
        }

        return $this;
    }

    public function __toString() {
        return $this->Namedomaine;
    }
   
    public function setAccesEvalFlashcardSeconde(bool $acces_eval_flashcard_seconde): static
    {
        $this->acces_eval_flashcard_seconde = $acces_eval_flashcard_seconde;

        return $this;
    }

    public function setAccesEvalFlashcardPremiere(bool $acces_eval_flashcard_premiere): static
    {
        $this->acces_eval_flashcard_premiere = $acces_eval_flashcard_premiere;

        return $this;
    }

    public function setAccesEvalFlashcardTerminale(bool $acces_eval_flashcard_terminale): static
    {
        $this->acces_eval_flashcard_terminale = $acces_eval_flashcard_terminale;

        return $this;
    }

    public function setAccesEvalFlashcardFac(bool $acces_eval_flashcard_fac): static
    {
        $this->acces_eval_flashcard_fac = $acces_eval_flashcard_fac;

        return $this;
    }

    public function setAccesEvalFlashcardSpecial(bool $acces_eval_flashcard_special): static
    {
        $this->acces_eval_flashcard_special = $acces_eval_flashcard_special;

        return $this;
    }

    public function setAccesFlashCardOutilGestion(bool $acces_flashcardoutilgestion): static
    {
        $this->acces_flashcardoutilgestion = $acces_flashcardoutilgestion;

        return $this;
    }

}
